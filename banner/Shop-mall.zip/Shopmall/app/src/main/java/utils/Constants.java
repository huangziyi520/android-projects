package utils;

public class Constants {
    public static String HOME_URL="http://192.168.1.77:8080/atguigu/json/HOME_URL.json";
}
