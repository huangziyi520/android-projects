package utils;

public class Constants {
    public static String BASE_URL = "http://192.168.1.77:8080/atguigu";
    public static String HOME_URL= BASE_URL +"/json/HOME_URL.json";
    public static String IMAGE_URL= BASE_URL +"/img";
}
